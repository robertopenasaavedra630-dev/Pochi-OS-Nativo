package com.pochi.os
import android.app.Activity
import android.os.Bundle
import android.widget.TextView
class MainActivity: Activity(){ override fun onCreate(b:Bundle?){super.onCreate(b); val t=TextView(this); t.text="🐶 Pochi OS\n🤖 Géminis\n📶 Wi-Fi"; setContentView(t)}}
